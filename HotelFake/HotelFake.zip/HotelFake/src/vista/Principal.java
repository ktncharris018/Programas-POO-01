
package vista;


import java.io.IOException;
import javax.swing.JOptionPane;
import modelo.*;

public class Principal {
    
   /* public static void main(String[] args){
        
            
        Hotel.registrarUsuario();
          
        Usuario.login();
    }*/
    public static void main(String[] args) throws IOException{
        Hotel hotel = new Hotel();
  
        Hotel.registrarUsuario("admin",100,0,"system","123","root");
       
        Login login = new Login();
  
    }
    
    
    
}
