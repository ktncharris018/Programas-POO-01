
package logica;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.*;
import persistencia.ArrayListUsuario;
import persistencia.*;

public class Coleccion {
    
    IHotel datos;

    public Coleccion()throws IOException  {
        
        //this.datos = new ArchivoObjeto();
        //this.datos = new baseDatos();
        this.datos = new ArrayListUsuario();
       
    }
    
    public void registrarUsuario(Usuario u, int cedula) throws IOException{
        this.datos.registraUsuario(u,cedula);
       
    }
    
    public Usuario buscar(int cedula) throws IOException{
        return this.datos.buscarUsuario(cedula);
    }
    
    public ArrayList<Usuario> informe() throws IOException{ 
        return this.datos.informeUsuario();
    }
    
    public Usuario validar(String usuario, String contraseña) throws IOException{
         return this.datos.validarUsuario(usuario, contraseña);
    }
    
    public boolean eliminarUsuaruo(int cedula){
        return this.datos.eliminarUsuario(cedula);
    }
    
    public void modificarUsuario(String nombre,int cedula,String user, String contraseña, String apellido) throws IOException{
        this.datos.modificarUsuario(nombre, cedula, user, contraseña, apellido);
    }
    
    //////////////////////////////////////////////////////////////7
    
    public void registrarHabitacion(Habitacion h) throws IOException{
        this.datos.registrarHabitacion(h);
    }
    
    public Habitacion buscarH(String idHabitacion) throws IOException{
        return this.datos.buscarHabitacion(idHabitacion);
    }
    
    public ArrayList<Habitacion> informeHabitacion() throws IOException{
        return this.datos.informeHabitacion();
    }
    
    public boolean eliminarHabitacion(String codigo) throws IOException{
        return this.datos.eliminarHabitacion(codigo);
    }
    
    public void modificarHabitacion(String codigo,int cantCamas,int cantBaños,
            int maxPersonas,double precio) throws IOException{
        this.datos.modificarHabitacion(codigo, cantCamas, cantBaños, maxPersonas, precio);
    }
    
    //////////////////////////////////////////////////////////////
    
    public void registrarHuesped(Huesped h) throws IOException{
        this.datos.registrarHuesped(h);
    }
    
    public Huesped buscarHuesped(int identificacion) throws IOException{
        return this.datos.buscarHuesped(identificacion);
    }
    
    public ArrayList<Huesped> informeHuespedes() throws IOException{
        return this.datos.informeHuespedes();
    }
    
    public boolean eliminarHuesped(int cedula){
        return this.datos.eliminarHuesped(cedula);
    }
    
    public void modificarHuesped(int identificacion, String pais, String nombre, String nombre2, String apellido, String apellido2, String email, Long telefono){
        this.datos.modificarHuesped(identificacion, pais, nombre, nombre2, apellido, apellido2, email, telefono);
    }
    
    ////////////////////////////////////////////////////////////////
    
    public void registrarReserva(Reserva r) throws IOException{
        this.datos.registrarReserva(r);
    }
    
    public Reserva buscarReserva(int cedula) throws IOException{
        return this.datos.buscarReserva(cedula);
    }
    
    public ArrayList<Reserva> informeReserva() throws IOException{
        return this.datos.informeReservas();
    }
    
    
    ///////////////////////////////////////////////////////////////////
    
    public void registrarServicio(Servicio s) throws IOException{
        this.datos.registrarServicio(s);
    }
    
    
    ////////////////////////////////////////////////////////////////////
    
    public void registrarFactura(Facturacion f) throws IOException{
        this.datos.registrarFactura(f);
    }
    
}
