
package persistencia;


import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JOptionPane;
import modelo.*;

public class ArrayListUsuario implements IHotel, Serializable{
    
    private ArrayList<Usuario> usuarios;
    private ArrayList<Habitacion> habitaciones;
    private ArrayList<Huesped> huespedes;
    private ArrayList<Reserva> reservas;
    private ArrayList<Servicio> servicios;
    private ArrayList<Facturacion> facturas;
    
    public ArrayListUsuario() {
        this.usuarios = new ArrayList();
        this.habitaciones = new ArrayList();
        this.huespedes = new ArrayList();
        this.reservas = new ArrayList();
        this.servicios = new ArrayList();
        this.facturas = new ArrayList();
    }

    @Override
    public void registraUsuario(Usuario u, int cedula)throws IOException {
     
        if(buscarUsuario(u.getCedula()) == null){
            this.usuarios.add(u);
            JOptionPane.showMessageDialog(null,"Usuario guardado");
        }else{
            JOptionPane.showMessageDialog(null,"Este usuario ya existe");
        }
  
    }

    @Override
    public Usuario buscarUsuario(int cedula)throws IOException {
        if(this.usuarios == null){
            return null;
        }  
        else{
            for(Usuario u: this.usuarios){
                if(u.getCedula() == cedula){
                    return u;
                
                }
            }
        }

        return null;
    }

    @Override
    public ArrayList<Usuario> informeUsuario(){
        return this.usuarios;
    }
    

    @Override
    public Usuario validarUsuario(String usuario, String contraseña)throws IOException {
       // int d;
        for(Usuario u: this.usuarios){
            if((u.getUser().equalsIgnoreCase(usuario)) && (u.getPassword().equals(contraseña))){
                //System.out.println("user = "+u.getUser()+" usuario = "+usuario+" uC = "+u.getPassword()+" contraseña = "+contraseña);
                //return true;
                //d = 0;
                //System.out.println(d);
                return u;
            }
        }
        return null;

        
    }

    @Override
    public void registrarHabitacion(Habitacion h) {
        if(buscarHabitacion(h.getIdHabitacion()) == null){
            this.habitaciones.add(h);
            JOptionPane.showMessageDialog(null,"Habitacion registrada");
        }else{
            JOptionPane.showMessageDialog(null,"Esta habitacion ya exite");
        }
    }

    @Override
    public Habitacion buscarHabitacion(String idHabitacion) {
    
        for(Habitacion h: this.habitaciones){
            if(h.getIdHabitacion().equalsIgnoreCase(idHabitacion)){
                return h;
            }
        }
        return null;
    }

    @Override
    public ArrayList<Habitacion> informeHabitacion() {
        
        for(Habitacion h: this.habitaciones){
            System.out.println(h);
            System.out.println("---------------");
        }
        return this.habitaciones;
    }

    @Override
    public void registrarHuesped(Huesped h) {
        if(buscarHuesped(h.getIdentificacion())== null){
            this.huespedes.add(h);
            JOptionPane.showMessageDialog(null,"Huesped registrado");
        }else{
            JOptionPane.showMessageDialog(null,"Este huesped ya se encuentra registrado");
        }
        
    }

    @Override
    public Huesped buscarHuesped(int identificacion) {
        
        for(Huesped h: this.huespedes){
            if(h.getIdentificacion() == identificacion){
                return h;
            }
        }
        return null;
    }
    

    @Override
    public ArrayList<Huesped> informeHuespedes() {
        
        for(Huesped h: this.huespedes){
            System.out.println(h);
            System.out.println("-------------------");
        }
        return this.huespedes;
    }

    @Override
    public void registrarReserva(Reserva r) {
        this.reservas.add(r);
    }

    @Override
    public ArrayList<Reserva> informeReservas() {
        for(Reserva r: this.reservas){
            System.out.println(r);
            System.out.println("------------------");
        }
        return this.reservas;
    }

    @Override
    public void registrarServicio(Servicio s) {
        this.servicios.add(s);
        System.out.println("Servicio registrado \n");
    }

    @Override
    public void registrarFactura(Facturacion f) {
         this.facturas.add(f);
    }

    @Override
    public Reserva buscarReserva(int cedula) {
        for(Reserva r: this.reservas){
            if(r.getHuesped().getIdentificacion() == cedula){
                return r;
            }
        }
        return null;
    }

    @Override
    public boolean eliminarUsuario(int cedula) {
        boolean resp = false;
        Iterator<Usuario> iterator = this.usuarios.iterator();
        while(iterator.hasNext()){
            Usuario usuario = iterator.next();
            if(usuario.getCedula() == cedula){
                iterator.remove();
                resp = true;
                break;
                
                
            }
            else{
                resp = false;
            }
        }
        return resp;
    }

    @Override
    public void modificarUsuario(String nombre,int cedula, String user, String contraseña, String apellido) throws IOException {
  
        buscarUsuario(cedula).setUserName(nombre);
        buscarUsuario(cedula).setApellido(apellido);
        buscarUsuario(cedula).setUser(user);
        buscarUsuario(cedula).setPassword(contraseña);
    }    

    @Override
    public boolean eliminarHabitacion(String codigo) {
        boolean resp = false;
        Iterator<Habitacion> iterator = this.habitaciones.iterator();
        while(iterator.hasNext()){
            Habitacion habitacion = iterator.next();
            if(habitacion.getIdHabitacion().equalsIgnoreCase(codigo)){
                iterator.remove();
                resp = true;
                break;
                
                
            }
            else{
                resp = false;
            }
        }
        return resp;
    }

    @Override
    public void modificarHabitacion(String codigo,int cantCamas,int cantBaños,
            int maxPersonas,double precio) {
        buscarHabitacion(codigo).setCantBaños(cantBaños);
        buscarHabitacion(codigo).setCantCamas(cantCamas);
        buscarHabitacion(codigo).setMaxPersonas(maxPersonas);
        buscarHabitacion(codigo).setPrecio(precio);
        
    }

    @Override
    public boolean eliminarHuesped(int cedula) {
        boolean resp = false;
        Iterator<Huesped> iterator = this.huespedes.iterator();
        while(iterator.hasNext()){
            Huesped huesped = iterator.next();
            if(huesped.getIdentificacion() == cedula ){
                iterator.remove();
                resp = true;
                break;
            }
            else{
                resp = false;
            }
        }
        return resp;
    }

    @Override
    public void modificarHuesped(int identificacion, String pais, String nombre, String nombre2, String apellido, String apellido2, String email, Long telefono) {
        buscarHuesped(identificacion).setNombreHuesped(nombre);
        buscarHuesped(identificacion).setNombreHuesped2(nombre2);
        buscarHuesped(identificacion).setApellidoHuesped(apellido);
        buscarHuesped(identificacion).setApellidoHuesped2(apellido2);
        buscarHuesped(identificacion).setEmial(email);
        buscarHuesped(identificacion).setTelefono(telefono);
        
    }
    
}
