
package persistencia;


import java.io.IOException;
import java.util.ArrayList;
import modelo.*;

public interface IHotel {
 
    void registraUsuario(Usuario u, int cedula)throws IOException;
    Usuario buscarUsuario (int cedula)throws IOException;
    ArrayList<Usuario> informeUsuario()throws IOException;
    Usuario validarUsuario(String usuario, String contraseña)throws IOException;
    boolean eliminarUsuario(int cedula);
    void modificarUsuario(String nombre,int cedula,String user, String contraseña, String apellido)throws IOException;
    
    void registrarHabitacion(Habitacion h)throws IOException;
    Habitacion buscarHabitacion(String idHabitacion)throws IOException;
    ArrayList<Habitacion> informeHabitacion()throws IOException;
    boolean eliminarHabitacion(String codigo)throws IOException;
    void modificarHabitacion(String codigo,int cantCamas,int cantBaños,int maxPersonas,double precio)throws IOException;
    
    
    void registrarHuesped(Huesped h)throws IOException;
    Huesped buscarHuesped(int identificacion)throws IOException;
    ArrayList<Huesped> informeHuespedes()throws IOException;
    boolean eliminarHuesped(int cedula);
    void modificarHuesped(int identificacion,String pais,
            String nombre, String nombre2, String apellido, String apellido2, String email, Long telefono);
    
    void registrarReserva(Reserva r)throws IOException;
    Reserva buscarReserva(int cedula)throws IOException;
    ArrayList<Reserva> informeReservas()throws IOException;
    
    void registrarServicio(Servicio s)throws IOException;
        
    void registrarFactura(Facturacion f)throws IOException;
}
