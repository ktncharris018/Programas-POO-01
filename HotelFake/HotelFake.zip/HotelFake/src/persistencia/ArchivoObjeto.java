/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import modelo.Facturacion;
import modelo.Habitacion;
import modelo.Huesped;
import modelo.Reserva;
import modelo.Servicio;
import modelo.Usuario;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KRISTAL DEL MAR
 */
public class ArchivoObjeto implements IHotel {
    private File archivo;
    private FileInputStream Lectura;
    private FileOutputStream Escritura;
    private ArrayListUsuario list;
    
     public ArchivoObjeto() {
        this("datos.obj");
    }

    public ArchivoObjeto(String name) {
        this.archivo = new File(name);
        
    }

    @Override
    public void registraUsuario(Usuario u, int cedula) throws IOException {
        this.leerLista();
        this.list.registraUsuario(u, cedula);
        this.guardarLista();
        
    }

    @Override
    public Usuario buscarUsuario(int cedula)throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<Usuario> informeUsuario() throws IOException{
        this.leerLista();
        return this.list.informeUsuario();
    }

    @Override
    public Usuario validarUsuario(String usuario, String contraseña) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean eliminarUsuario(int cedula) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void modificarUsuario(String nombre, int cedula, String user, String contraseña, String apellido) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void registrarHabitacion(Habitacion h) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Habitacion buscarHabitacion(String idHabitacion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<Habitacion> informeHabitacion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean eliminarHabitacion(String codigo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void modificarHabitacion(String codigo, int cantCamas, int cantBaños, int maxPersonas, double precio) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void registrarHuesped(Huesped h) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Huesped buscarHuesped(int identificacion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<Huesped> informeHuespedes() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void registrarReserva(Reserva r) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Reserva buscarReserva(int cedula) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<Reserva> informeReservas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void registrarServicio(Servicio s) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void registrarFactura(Facturacion f) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private void leerLista() throws IOException {

        if (!this.archivo.exists()) {
            this.list = new ArrayListUsuario();
             
        } 
        else{
            ObjectInputStream ois = null;
            try {
                this.Lectura = new FileInputStream(this.archivo);
                ois = new ObjectInputStream(this.Lectura);
                this.list = (ArrayListUsuario) ois.readObject();

            } catch (IOException ioe) {
                throw new IOException("El archivo no existe o no pudo ser leido");
            } catch (ClassNotFoundException ex) {
                throw new IOException("El formato del archivo no es correcto, no es una lista de vehiculo");
            } finally {
                if (ois != null) {
                    ois.close();
                }
                if (this.Lectura != null) {
                    this.Lectura.close();
                }

            }
        }
       
    }
    
    private void guardarLista() throws IOException {
        ObjectOutputStream oos = null;
        try {
            this.Escritura = new FileOutputStream(this.archivo);
            oos = new ObjectOutputStream(this.Escritura);
            oos.writeObject(this.list);

        } catch (IOException ioe) {
            throw new IOException("No es posible crear el archivo para escritura");
        } finally {
            if (oos != null) {
                oos.close();
            }
            if (this.Escritura != null) {
                this.Escritura.close();
            }
        }

    }

    @Override
    public boolean eliminarHuesped(int cedula) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void modificarHuesped(int identificacion, String pais, String nombre, String nombre2, String apellido, String apellido2, String email, Long telefono) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
