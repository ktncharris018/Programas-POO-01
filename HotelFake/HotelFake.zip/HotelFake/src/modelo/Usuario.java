
package modelo;


import java.io.IOException;
import javax.swing.JOptionPane;
import vista.vista;
import vista.vistaRecepcion;

public class Usuario {
    
    protected String userName;
    protected String password;
    protected String estado;
    protected int cedula;
    protected String user;
    protected String roll;
    protected String apellido;
    
    public Usuario(){
        
    }

    public Usuario(String userName, String password, int cedula, String user, String roll, String apellido) {
        this.userName = userName;
        this.password = password;
        this.estado = "activo";
        this.cedula = cedula;
        this.user = user;
        this.roll = roll;
        this.apellido = apellido;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getRoll() {
        return roll;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }
    
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public static void login(String usuario, String contraseña) throws IOException{
        
        if(Hotel.validar(usuario, contraseña) == null){
            JOptionPane.showMessageDialog(null,"Algo salio mal");
            
        }else{
            if(Hotel.validar(usuario, contraseña).roll.equalsIgnoreCase("admin")){
                vista admin = new vista();
            }else if (Hotel.validar(usuario, contraseña).roll.equalsIgnoreCase("recepcion")){
                //Recepcionista.menu();
                vistaRecepcion recepcion = new vistaRecepcion();
            }else{
                System.out.println("Inconsistencia");
            }
        }
       
        
    }
    
    @Override
    public String toString() {
        return "Nombre = "+userName+"\nApellido = "+apellido+"\nCedula = "+cedula+"\nUsuario = "+user+"\nTipo usuario = "+roll;
    }
    
    

              
    
}
