
package modelo;


import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import logica.Coleccion;
 
public class Hotel {
    
    static Coleccion c ;
    public Hotel() throws IOException{
        c = new Coleccion();
        System.out.println("Constructor de Hotel llamado");
    }
  
    public static void imprimirUsuario (Usuario u){
         System.out.println(u);
    }
    
       
    public static void consultarUsuario(int cedula) throws IOException{
        
        //cedula = Entrada.leerInt("Digite la cedula: ");
        
        if(c.buscar(cedula) == null){
            JOptionPane.showMessageDialog(null,"Este usuario No existe");
            //return null;
        }else{
            JOptionPane.showMessageDialog(null,"Usuario encontrado\n"+c.buscar(cedula));
           // imprimirUsuario(c.buscar(cedula));
            //return c.buscar(cedula);
            //return c.buscar(cedula);
        }
      //return null;
    }
   
    
    public static Usuario registrarUsuario(String nombre,int cedula, int tipoUsuario, String user, String contraseña, String apellido) throws IOException{
        
        System.out.println("--------------------------------------");
        Usuario u;
        
        if(tipoUsuario == 0){
            u = new Usuario(nombre,contraseña,cedula, user, "admin",apellido);
            c.registrarUsuario(u,cedula);
            return u; 
        }else{
            u = new Usuario(nombre, contraseña,cedula,user, "recepcion",apellido);
            c.registrarUsuario(u,cedula);
            return u;
        }
             
    }
   
    public static ArrayList<Usuario> listaUsuario() throws IOException{
        //System.out.println("** Lista Usuarios **");
        return c.informe();
        
    }
    
    public static Usuario validar(String usuario, String contraseña) throws IOException{
        
        return c.validar(usuario, contraseña);
        
    }
    
    public static void eliminarUsuario(int cedula){
        if(c.eliminarUsuaruo(cedula)){
            JOptionPane.showMessageDialog(null, "Usuario eliminado");
        }else{
            JOptionPane.showMessageDialog(null, "Este usuario NO existe");
        }
    }
   
    
    public static void modificarUsuario(int cedula) throws IOException{
        if(c.buscar(cedula) != null){
            String nombre = JOptionPane.showInputDialog("Nombre: ");
            String apellido = JOptionPane.showInputDialog("Apellido: ");
            String user = JOptionPane.showInputDialog("Usuario : ");
            String contraseña = JOptionPane.showInputDialog("Contraseña: ");
            c.modificarUsuario(nombre, cedula, user, contraseña, apellido);
            JOptionPane.showMessageDialog(null, "Usuario modifcado");
        }else{
            JOptionPane.showMessageDialog(null, "este usuario No esta registrado");
        }
    }
    
    ////////////////////// HABITACIONES ////////////////////////////////////////
    
    public static void registrarHabitacion(int tipo,String idHabitacion,int cantCamas,int cantBaños,
            int maxPersonas,double precio,int tipoCama, int tipoBaño) throws IOException{
    
        Habitacion h;

        if(tipo == 0){
            h = new HabitacionSimple("simple",idHabitacion,cantCamas,cantBaños,maxPersonas,precio);
            c.registrarHabitacion(h);
        }else{
            h = new HabitacionDoble(tipoCama, tipoBaño, "Doble", idHabitacion,cantCamas, cantBaños, maxPersonas, precio);
            c.registrarHabitacion(h);
        }
        
    }
    

    
    public static void consultarHabitacion() throws IOException{
        String codigo = JOptionPane.showInputDialog("Digite el codigo a buscar: ");
        if(c.buscarH(codigo) == null){
            JOptionPane.showMessageDialog(null,"Esta habitacion no existe");
        }else{
            JOptionPane.showMessageDialog(null,"Habitacion encontrada\n"+c.buscarH(codigo));
           
        }
    }
    
    public static ArrayList<Habitacion> informeHabitaciones() throws IOException {
       
        return c.informeHabitacion();
    }
    
    public static void eliminarHabitacion() throws IOException{
        String codigo = JOptionPane.showInputDialog("Codigo a eliminar: ");
        if(c.eliminarHabitacion(codigo)){
            JOptionPane.showMessageDialog(null, "Habitacion eliminado");
        }else{
            JOptionPane.showMessageDialog(null, "Esta habitacion NO existe");
        }
    }
    
    public static void modificarHabitacion() throws IOException{
        String codigo = JOptionPane.showInputDialog("Codigo de habitacion a modificar: ");
        if(c.buscarH(codigo) != null){
            int camas = Integer.parseInt(JOptionPane.showInputDialog("cantidad camas: "));
            int baños = Integer.parseInt(JOptionPane.showInputDialog("cantidad baños: "));
            int personas = Integer.parseInt(JOptionPane.showInputDialog("Pesonas maximas: "));
            double precio = Double.parseDouble(JOptionPane.showInputDialog("Precio: "));
            c.modificarHabitacion(codigo, camas, baños, personas, precio);
            JOptionPane.showMessageDialog(null, "Habitacion modificada");
        }else{
            JOptionPane.showMessageDialog(null, "esta habitacion no esta registrada");
        }
    }
    
    
  ///////////////////////// HUESPEDES /////////////////////////////////////////
    
    
    public static void registrarHuesped(int tipoIdentificacion, int identificacion,String pais,
            String nombre, String nombre2, String apellido, String apellido2, String email, Long telefono) throws IOException{
    
        Huesped h;
        if(tipoIdentificacion == 0){
            h = new Huesped("nacional", identificacion, pais, nombre, apellido, email, telefono,nombre2,apellido2);
            c.registrarHuesped(h);
        }else{
            h = new Huesped("extrenjera", identificacion, pais, nombre, apellido, email, telefono,nombre2,apellido2);
            c.registrarHuesped(h);
        }


    }
    
    public static void imprimirHuesped(Huesped h){
        System.out.println(h);
    }
    
    public static void consultarHuesped() throws IOException{
        int identificacion = Integer.parseInt(JOptionPane.showInputDialog("Identificacion a buscar: "));
        if(c.buscarHuesped(identificacion)== null){
            JOptionPane.showMessageDialog(null,"Este Huesped no se encuentra registrado");
            
        }else{
            JOptionPane.showMessageDialog(null,"Huesped encontrado\n"+c.buscarHuesped(identificacion));
            c.buscarHuesped(identificacion);
        }
    }
    
    public static ArrayList<Huesped> informeHuespedes() throws IOException{
        
        return c.informeHuespedes();
    }
    
    public static void eliminarHuesped(){
        int cedula = Integer.parseInt(JOptionPane.showInputDialog("Identificacion a eliminar: "));
        if(c.eliminarHuesped(cedula)){
            JOptionPane.showMessageDialog(null, "Huesped eliminado");
        }else{
            JOptionPane.showMessageDialog(null,"Este huesped no se encuentra registrado");
        }
    }
    
    public static void modificarHuesped() throws IOException{
        int cedula = Integer.parseInt(JOptionPane.showInputDialog("Identificacion a modificar: "));
        if(c.buscarHuesped(cedula) != null){
           
            String pais = JOptionPane.showInputDialog("Pais: ");
            String nombre1 = JOptionPane.showInputDialog("Primer nombre: ");
            String nombre2 = JOptionPane.showInputDialog("Segundo nombre: ");
            String apellido1 = JOptionPane.showInputDialog("Primer apellido: ");
            String apellido2 = JOptionPane.showInputDialog("Segundo apellido: ");
            String email = JOptionPane.showInputDialog("email: ");
            Long telefono = Long.parseLong(JOptionPane.showInputDialog("Telefono: "));
            c.modificarHuesped(cedula, pais, nombre2, nombre2, apellido2, apellido2, email, telefono);
            JOptionPane.showMessageDialog(null, "Usuario modificado");
        }else{
            JOptionPane.showMessageDialog(null, "Esta habitacion nno estaregistrada");
        }
    }
    
    
    ///////////////////// RESERVAS ////////////////////////////////////////
    public static void registrarReserva(LocalDate fechaIn, LocalDate fechaOut,int identificacion, String idHabitacion) throws IOException{
        
        Reserva r;
        
        //LocalDate fechaIn = LocalDate.parse(Entrada.leerString("Fecha llegada(aaaa-mm-dd): "));
        //LocalDate fechaOut = LocalDate.parse(Entrada.leerString("Fecha salida(aaaa-mm-dd): "));
        //int identificacion = Entrada.leerInt("Identificacion del huespes: ");
        //String idHabitacion = Entrada.leerString("Id de Habitacion: ");
        
        if((c.buscarHuesped(identificacion) == null) || (c.buscarH(idHabitacion) == null)){
            JOptionPane.showMessageDialog(null,"No se pudo realizar la reserva por inconsistencia en los datos");
        }else if((c.buscarHuesped(identificacion).getEstado().equals("Hospedado")) || (c.buscarH(idHabitacion).getEstado().equals("No disponible"))){
            JOptionPane.showMessageDialog(null,"No se pudo realizar la reserva por el estado");
        }
        else{
            r = new Reserva(fechaOut, fechaIn,c.buscarHuesped(identificacion),c.buscarH(idHabitacion));
            c.registrarReserva(r);
            c.buscarHuesped(identificacion).setEstado("Hospedado");
            c.buscarH(idHabitacion).setEstado("No disponible");
            JOptionPane.showMessageDialog(null,"Reserva realizada con exito");
        }     
    }
    
    public static ArrayList<Reserva> informeReserva() throws IOException{
        return c.informeReserva();
    }
    
    public static void registrarServicio() throws IOException{
        Servicio s;
        int identificacion = Entrada.leerInt("identificacion del huesped: ");
        if(c.buscarHuesped(identificacion) == null){
            System.out.println("Este usuario no se encuentra registrado");
        }
        else if((c.buscarHuesped(identificacion).getEstado().equals("Hospedado"))){
            int op = Entrada.leerInt("\n1.Lavado \n2.Transporte \n3.Estacionamiento \nQue servicio desea elegir: ");
            if(op == 1){
                String descrpcion = Entrada.leerString("Descripcion: ");
                int cant = Entrada.leerInt("Cantidad de prendas: ");
                int tipo = Entrada.leerInt("Tipo de prenda \n1.normal(2000) \n2.Fina(5000) : ");
                double precio;
                if(tipo == 1){
                    precio = 2000;
                }else{
                    precio = 5000;
                }
                
                s = new Lavado(precio,cant,"Lavado",descrpcion,0);
                s.setTotal(s.calcularPrecio());
                System.out.println("Total a pagar = "+s.calcularPrecio());
               
                System.out.println("En serivicios llevas un total de = "+c.buscarHuesped(identificacion).totalPagarServicio(s.calcularPrecio()));
                c.registrarServicio(s);
                
            }
            else if(op == 2){
                String descripcion = Entrada.leerString("Descripcion: ");
                double distancia = Entrada.leerDouble("Distancia recorrida: ");
                int chofer = Entrada.leerInt("Va a llevar chofer \n1.Si \n2.No :");
                if(chofer == 1){
                    s = new Transporte(distancia,true,"Transporte",descripcion,0);
                    s.setTotal(s.calcularPrecio());
                    System.out.println("Total a pagar = "+s.calcularPrecio());
                    
                    System.out.println("En servicios llevas un total de = "+c.buscarHuesped(identificacion).totalPagarServicio(s.calcularPrecio()));
                    c.registrarServicio(s);
                }else{
                    s = new Transporte(distancia,false,"Transporte",descripcion,0);
                    s.setTotal(s.calcularPrecio());
                    System.out.println("Total a pagar = "+s.calcularPrecio());
                    
                    System.out.println("En servicios llevas un total de = "+c.buscarHuesped(identificacion).totalPagarServicio(s.calcularPrecio()));
                    c.registrarServicio(s);
                }
            }
            else if(op == 3){
                String descripcion = Entrada.leerString("Descripcion: ");
                int horas = Entrada.leerInt("cantidad de horas: ");
                s = new Estacionamiento(horas,"Estacionamiento",descripcion,0);
                s.setTotal(s.calcularPrecio());
                System.out.println("Total a pagar = "+s.calcularPrecio());
                
                System.out.println("En servicios llevas un total de = "+c.buscarHuesped(identificacion).totalPagarServicio(s.calcularPrecio()));
                c.registrarServicio(s);
            }
            else {
                System.out.println("opcion invalida");
            }
        }else{
            System.out.println("Este usuario no se encuentra hospedad");
        }
        
    }
    
    public static void registrarFactura(int identificacion) throws IOException{
 
        Facturacion f;
        if(c.buscarReserva(identificacion) == null){
            JOptionPane.showMessageDialog(null,"Este usuario no se encuentra registrado 1");
            
        }else if(c.buscarHuesped(identificacion).getEstado().equalsIgnoreCase("Hospedado")){
            f = new Facturacion(LocalDate.now(),c.buscarReserva(identificacion));
            c.buscarHuesped(identificacion).setEstado("No hospedado");
            c.buscarReserva(identificacion).getHabitacion().setEstado("Disponible");
            
            JOptionPane.showMessageDialog(null, f);
            
        }
        else{
            JOptionPane.showMessageDialog(null,"Este usuario No se encuentra hospedado");
            
        }
    }
}
    
    

    
  
