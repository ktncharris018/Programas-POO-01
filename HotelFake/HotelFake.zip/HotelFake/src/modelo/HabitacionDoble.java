
package modelo;

public class HabitacionDoble extends Habitacion{
    
    private int tipoCama;
    private int tipoBaño;
    
    public HabitacionDoble(){
        
    }

    public HabitacionDoble(int tipoCama, int tipoBaño,String tipoH, String idHabitacion,
          int cantCamas, int cantBaños, int maxPersonas, double precio) {
        super(tipoH, idHabitacion,cantCamas, cantBaños, maxPersonas, precio);
        this.tipoCama = tipoCama;
        this.tipoBaño = tipoBaño;
    }

    public int getTipoBaño() {
        return tipoBaño;
    }

    public void setTipoBaño(int tipoBaño) {
        this.tipoBaño = tipoBaño;
    }

    public int getTipoCama() {
        return tipoCama;
    }

    public void setTipoCama(int tipoCama) {
        this.tipoCama = tipoCama;
    }

    @Override
    public double calcularPrecio() {
        return this.precio;
    }

    @Override
    public String toString() {
        return super.toString()+"\nTipo de Cama = "+tipoCama+"\nTipo de Baño = "+tipoBaño;
    }

 
    
    
    
    
    
}
