
package modelo;

public class HabitacionSimple extends Habitacion{
    
    public HabitacionSimple(){
        
    }

    public HabitacionSimple(String tipoH, String idHabitacion,int cantCamas, int cantBaños, int maxPersonas, double precio) {
        super(tipoH, idHabitacion, cantCamas, cantBaños, maxPersonas, precio);
    }

    @Override
    public double calcularPrecio() {
        return precio;
    }
    
    
}
